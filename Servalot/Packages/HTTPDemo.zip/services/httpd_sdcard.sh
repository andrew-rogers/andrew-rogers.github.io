. /sdcard/httpd_example.sh

