echo "HTTP/1.0 200"
echo "Content type: text/html"
echo
echo "<html><body>"
echo "$PATH"
echo "</body></html>"

